# Interpolation of Images

# Usage

To Install this package. Use :
```
  pip install cvpolation
  ```


<b>Use the below snipit to start using the package.</b>
```
 from cvpolation import *
```

<b>NQueens Possible Solution Space </b>
   ```
   ir = Interpolation()
   ir.get_user_input()
   ```

<dl>Visit our GitHub Repository for more information: https://github.com/toshihiroryuu/</dl>
<dl>About the Author: http://athulmathew.com</dl>
